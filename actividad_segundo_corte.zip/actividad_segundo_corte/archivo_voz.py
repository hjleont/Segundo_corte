# importa la libreria que nos convertira el archivo
from gtts import gTTS

# importamos esta libreria para escuchar el archivo
import os

def archivo_voz():
    
    # Se crea esta variable para llamar el archivo .txt
    file = open("argumento.txt", "r").read().replace("\n", " ")
    
    # este parametro dara el lenguaje del texto convertido
    language = 'es-us'
    
    # este parametro unira tanto el texto como el lenguaje para convertir el archivo
    speech = gTTS(text = str(file), lang = language, slow = False)
    
    # Este parametro generara el archivo convertivo
    speech.save("voz.mp3")
    
    # a llamar esta libreria nos guardara el archivo de voz
    os.system("start voz.mp3")
    
archivo_voz ()    