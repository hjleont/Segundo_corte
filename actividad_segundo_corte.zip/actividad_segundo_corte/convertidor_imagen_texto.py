# se importan las siguientes librerias para sacar las palabras de la imagen
from PIL import Image
from pytesseract import *

# se importa la siguiente libreria para traducir el texto
from textblob import TextBlob

# se hace el llamado de la libreria mediante la siguiente
pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# se crea una variable donde llamamos la imagen guardada
def img():
    img= Image.open("frace1.jpg")
    
    # se crea la variable resultado para guardar la informacion tomada de la imagen
    resultado = pytesseract.image_to_string(img)

    # se llama este metodo para crear el archivo txt
    with open ("texto.txt","w") as file_object:
        file_object.write(resultado)

    # se llama la libreria mediante la variable para hacer la traducción
    texto_ingles = TextBlob(resultado) 
    
    # llamara el texto en ingles y lo traducira al español  
    texto_español=str(texto_ingles.translate(from_lang="en", to="es"))
    
    # se imprimira el texto en consola traducido
    print(texto_español) 
    
    # se llevara el texto al txt por el metodo apend
    with open ("imagens_textos.txt","a") as file_object:
        file_object.write(texto_español)       
img()