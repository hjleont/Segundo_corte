# Se crea una variable llamando el archivo que utilizaremos
filename = 'argumento.txt'

# Se crea un parametro que validara el archivo txt si no enviara un mensaje 
try:
    with open(filename) as f_obj:
        contents = f_obj.read()

except FileNotFoundError:

    def msg(mensaje):
        mensaje = "El texto" + filename + "no esta disponible por favor verificar"
    print(msg)

# Al validar el archivo se realizara mediante la variable y contara palabras 
else:
    palabra = contents.split()
    num_palabras = len(palabra)
    
    # Mediante al bucle se realizara cuenta de los saltos de lineas
    n = 0
    for i in contents:
        if i =="\n":
            n += 1
    
    # Este bucle contara los caracteres totales del archivo        
    caracter = 0
    for c in contents:
        if c == c.isdigit() or c.isalpha():
            caracter += 1
    
    # Este variable enviara el resultado a otro archivo txt
    archivo = open('Resultado_Texto.txt','w')
    
    # Estos parametros imprimira cada uno de los resultados 
    archivo.write("1. El texto tiene un total de: " + str (n) + " saltos de linea."+"\n")
    archivo.write("2. El texto tiene un total de: " + str (num_palabras) + " palabras, sin contar los espacios."+"\n")
    archivo.write("3. El texto tiene un total de: " + str (caracter) + " caracteres."+"\n")
    archivo.write("4. En el texto La palabra (tarjeta) se encuenta: " + str( palabra.count('tarjeta')) + " veces.")
    archivo.close()
