print("Programa Generador de Contraseñas Aleatorias");
print("");

# importamos la siguiente libreria para nuestro generador
import random

# Definimos las variables de las cuales utilizaremos
letras = "abcdefghijklmnopqrstuvwxysABCDEFGHIJKLMNOPQRSTUVWXYZ"
numeros = "0123456789"
simbolos = "!#$%&/()?¡¿[]+}<{>@"

# Con la siguiente variable unificamos las otras anteriores
def unir():
    unir = f'{letras}{numeros}{simbolos}'

    # esta variable nos dara la longitud de la contraseña 
    longitud = 12

    # esta variable nos une la variable unir con longitud
    contraseña = random.sample(unir, longitud)

    # esta variable generara la contraseña
    generador_final = "".join(contraseña)

    # esta funcion generara el archivo txt segun como decidamos llamarlo y se reescribira cada vez que generemos la contraseña 
    with open ("passwords.txt", "w") as file_object:
        file_object.write(generador_final)
    
    # Imprimira la cantraseña aleatoria   
    print(generador_final)
unir()